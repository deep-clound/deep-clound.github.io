var schedule = require('node-schedule');
exports.winston=winston = require('winston');

winston.add(winston.transports.File, { filename: './logs/task1.log' });
winston.remove(winston.transports.Console);


var task1 = schedule.scheduleJob('* * */12 * * *', require('./tasks/task1'));
