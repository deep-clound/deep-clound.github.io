module.exports=function(){

  var winston = require('../crontasks').winston;
  winston.level = 'debug';

  winston.info('开始执行task1');

  winston.debug('task1返回结果:123');
}
